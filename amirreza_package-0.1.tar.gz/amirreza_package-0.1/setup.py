from setuptools import setup

setup(
    name='amirreza_package',
    packages=['amirreza_package'],
    description='Hello world enterprise edition',
    version='0.1',
    url='https://github.com/amirsed76/amirreza_package',
    author='amirreza',
    author_email='amirreza.seddighin1376@gmail.com',
    keywords=['pip', 'linode', 'example']
)
